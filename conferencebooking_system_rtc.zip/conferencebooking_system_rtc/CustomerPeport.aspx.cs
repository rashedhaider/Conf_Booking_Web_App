﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

public partial class Customer_report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=Login to your accout. To access the page !!!");
        }
        showDataListing();
    }

    public void showDataListing()
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM customer, city WHERE customer_city = city_id";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        adp.Fill(data);
        DataReportListing.DataSource = data;
        DataReportListing.DataBind();
        mzh.con.Close();
    }

    protected void deleteData_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        DBConnection mzh = new DBConnection();
        String SQL = "DELETE FROM customer WHERE customer_id = @0";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        cmd.Parameters.AddWithValue("@0", btn.CommandArgument);
        cmd.ExecuteNonQuery();
        showDataListing();
    }

    protected void editData_Click(object sender, EventArgs e)
    {
    }
}
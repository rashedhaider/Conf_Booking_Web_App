﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        room_id.Text = Request.QueryString["room_id"];
    }

    public DataTable showDataListing()
    {
        DBConnection mzh = new DBConnection();
        String id = Request.QueryString["room_id"];
        String SQL = "SELECT * FROM `room`,`type` WHERE room_type_id = type_id AND room_id = '" + id + "'";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        adp.Fill(data);
        mzh.con.Close();
        return data;
    }
    public Boolean checkApplication()
    {
        String id = Request.QueryString["room_id"];
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT* from apply WHERE  apply_room_id = '" + id + "' AND  apply_user_id = '" + Session["users_id"] + "'";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        adp.Fill(data);
        mzh.con.Close();
        if (data.Rows.Count == 0)
            return true;
        return false;
    }
    protected void applyRoom_Click(object sender, EventArgs e)
    {
        String id = Request.QueryString["room_id"];
        DBConnection mzh = new DBConnection();
        String SQL;
        String date = (DateTime.Today).ToString();
        SQL = "INSERT INTO `apply` (`apply_room_id`, `apply_user_id`, `apply_date`) VALUES (@1, @2, @3);";
        MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
        insertCommandfrommzh.CommandType = CommandType.Text;

        insertCommandfrommzh.Parameters.AddWithValue("@1", id);
        insertCommandfrommzh.Parameters.AddWithValue("@2", Session["users_id"]);
        insertCommandfrommzh.Parameters.AddWithValue("@3", date);

        insertCommandfrommzh.ExecuteNonQuery();
        mzh.con.Close();
        Response.Redirect("RoomsDetails.aspx?room_id=" + id+"&msg=You have successfully applied for the room");
    }
}
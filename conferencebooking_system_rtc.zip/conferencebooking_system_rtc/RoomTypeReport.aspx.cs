﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

public partial class RoomType_report : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=To Access ! You to Login your Account OK ? !!!");
        }
        showDataListing();
    }

    public void showDataListing()
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM type";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        adp.Fill(data);
        DataReportListing.DataSource = data;
        DataReportListing.DataBind();
        mzh.con.Close();
    }

    protected void deleteData_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        DBConnection mzh = new DBConnection();
        String SQL = "DELETE FROM type WHERE type_id = @0";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        cmd.Parameters.AddWithValue("@0", btn.CommandArgument);
        cmd.ExecuteNonQuery();
        showDataListing();
    }

    protected void editData_Click(object sender, EventArgs e)
    {
    }
}
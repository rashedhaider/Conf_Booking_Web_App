﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;


public partial class Audi : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String id;
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=Login to your accout. To access the page !!!");
        }
        booking_amount.Text = Request.QueryString["amt"];
    }
    protected void save_data_Click(object sender, EventArgs e)
    {
        Response.Redirect("PrintReceipt.aspx?booking_id="+ Request.QueryString["booking_id"]);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class Designation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=Login to your accout. To access the page !!!");
        }
    }
    protected void changePassword_Click(object sender, EventArgs e)
    {
        
        DBConnection mzh = new DBConnection();
        String SQL = "select * from customer where customer_id = @userID";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        cmd.Parameters.AddWithValue("@userID", Session["users_id"]);
        MySqlDataAdapter mzh1 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh1.Fill(data);
        if (data.Rows.Count > 0)
        {
            DataRow dr = data.Rows[0];
            if (old_password.Text != Convert.ToString(dr["customer_password"]))
            {
                Response.Redirect("Customer-password.aspx?msg=Invalid Old Password. Try Again !!!");
            }
            else
            {
                SQL = "UPDATE customer set customer_password = @0 WHERE customer_id = @1";
                MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
                insertCommandfrommzh.CommandType = CommandType.Text;

                insertCommandfrommzh.Parameters.AddWithValue("@0", new_password.Text);
                insertCommandfrommzh.Parameters.AddWithValue("@1", Session["users_id"]);
                insertCommandfrommzh.ExecuteNonQuery();
                mzh.con.Close();
                old_password.Text = "";
                new_password.Text = "";
                confirm_password.Text = "";
                Response.Redirect("Customer-password.aspx?msg=Password changed successfully.");
            }
        }
    }
}
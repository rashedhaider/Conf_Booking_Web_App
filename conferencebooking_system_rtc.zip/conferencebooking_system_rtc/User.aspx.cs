﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class Demoasp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String id;
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=Login to your accout. To access the page !!!");
        }
        if (!Page.IsPostBack && !String.IsNullOrEmpty(Request.QueryString["user_id"]))
        {
            id = Request.QueryString["user_id"];
            editData(id);
        }
        if (!Page.IsPostBack)
        {
            FillDepartmentListing();
            FillDesignationListing();
            FillLoginLevelListing();
            FillCityListing();
            FillStateListing();
            FillCountryListing();
        }
    }
    public void editData(String id)
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM user WHERE user_id = '" + id + "'";
        MySqlCommand command = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(command);
        adp.Fill(data);
        DataRow dear = data.Rows[0];
        user_id.Text = Convert.ToString(dear["user_id"]);
        user_designation_id.Text = Convert.ToString(dear["user_designation_id"]);
        user_department_id.Text = Convert.ToString(dear["user_department_id"]);
        user_level_id.Text = Convert.ToString(dear["user_level_id"]);
        user_name.Text = Convert.ToString(dear["user_name"]);
        user_add1.Text = Convert.ToString(dear["user_add1"]);
        user_add2.Text = Convert.ToString(dear["user_add2"]);
        user_city.Text = Convert.ToString(dear["user_city"]);
        user_state.Text = Convert.ToString(dear["user_state"]);
        user_country.Text = Convert.ToString(dear["user_country"]);
        user_email.Text = Convert.ToString(dear["user_email"]);
        user_mobile.Text = Convert.ToString(dear["user_mobile"]);
        user_gender.Text = Convert.ToString(dear["user_gender"]);
        user_dob.Text = Convert.ToString(dear["user_dob"]);
        user_details.Text = Convert.ToString(dear["user_details"]);

        mzh.con.Close();
    }
    protected void save_data_Click(object sender, EventArgs e)
    {
        DBConnection mzh = new DBConnection();
        String SQL;

        if (!String.IsNullOrEmpty(user_id.Text))
        {
            SQL = "UPDATE `user` SET `user_designation_id` = @0, `user_department_id` = @1, `user_level_id` = @2, `user_name` = @5, `user_add1` = @6, `user_add2` = @7, `user_city` = @8, `user_state` = @9, `user_country` = @10, `user_email` = @11, `user_mobile` = @12, `user_gender` = @13, `user_dob` = @14, `user_details` = @15 WHERE `user_id` = @16";
        }
        else
        {
            SQL = "INSERT INTO `user` (`user_designation_id`, `user_department_id`, `user_level_id`, `user_username`, `user_password`, `user_name`, `user_add1`, `user_add2`, `user_city`, `user_state`, `user_country`, `user_email`, `user_mobile`, `user_gender`, `user_dob`, `user_details`) VALUES (@0, @1, @2, @3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13, @14, @15)";
        }
        MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
        insertCommandfrommzh.CommandType = CommandType.Text;

        insertCommandfrommzh.Parameters.AddWithValue("@0", user_designation_id.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@1", user_department_id.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@2", user_level_id.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@3", user_username.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@4", user_password.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@5", user_name.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@6", user_add1.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@7", user_add2.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@8", user_city.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@9", user_state.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@10", user_country.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@11", user_email.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@12", user_mobile.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@13", user_gender.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@14", user_dob.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@15", user_details.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@16", user_id.Text);
        insertCommandfrommzh.ExecuteNonQuery();
        mzh.con.Close();
        Response.Redirect("~/UserReport.aspx"); 
    }
    private void FillDepartmentListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From department", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        user_department_id.DataValueField = "department_title";
        user_department_id.DataTextField = "department_title";
        user_department_id.DataSource = data;
        user_department_id.DataBind();
        user_department_id.Items.Insert(0, "Please Select");
    }
    private void FillDesignationListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From designation", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        user_designation_id.DataValueField = "designation_title";
        user_designation_id.DataTextField = "designation_title";
        user_designation_id.DataSource = data;
        user_designation_id.DataBind();
        user_designation_id.Items.Insert(0, "Please Select");
    }
    private void FillLoginLevelListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From login_level", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        user_level_id.DataValueField = "ll_id";
        user_level_id.DataTextField = "ll_title";
        user_level_id.DataSource = data;
        user_level_id.DataBind();
        user_level_id.Items.Insert(0, "Please Select");
    }
    private void FillCityListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From city", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        user_city.DataValueField = "city_name";
        user_city.DataTextField = "city_name";
        user_city.DataSource = data;
        user_city.DataBind();
        user_city.Items.Insert(0, "Please Select");
    }
    private void FillStateListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From state", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        user_state.DataValueField = "state_name";
        user_state.DataTextField = "state_name";
        user_state.DataSource = data;
        user_state.DataBind();
        user_state.Items.Insert(0, "Please Select");
    }
    private void FillCountryListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From country", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        user_country.DataValueField = "country_name";
        user_country.DataTextField = "country_name";
        user_country.DataSource = data;
        user_country.DataBind();
        user_country.Items.Insert(0, "Please Select");
    }
}
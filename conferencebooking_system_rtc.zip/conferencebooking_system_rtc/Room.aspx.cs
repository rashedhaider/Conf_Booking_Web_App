﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;


public partial class Room : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String id;
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=To Access ! You to Login your account !!!");
        }
        if (!Page.IsPostBack && !String.IsNullOrEmpty(Request.QueryString["room_id"]))
        {
            id = Request.QueryString["room_id"];
            editData(id);
        }
        if (!Page.IsPostBack)
        {
            FillTypeListing();
        }

    }
    public void editData(String id)
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM `room` WHERE room_id = '" + id + "'";
        MySqlCommand command = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(command);
        adp.Fill(data);
        DataRow dear = data.Rows[0];
        room_name.Text = Convert.ToString(dear["room_name"]);
        upload_picture.Text  = Convert.ToString(dear["room_image"]);
        room_no_of_beds.Text = Convert.ToString(dear["room_no_of_beds"]);
        room_type_id.Text = Convert.ToString(dear["room_type_id"]);
        room_max_adult.Text = Convert.ToString(dear["room_max_adult"]);
        room_max_child.Text = Convert.ToString(dear["room_max_child"]);
        room_description.Text = Convert.ToString(dear["room_description"]);
        room_fare.Text = Convert.ToString(dear["room_fare"]);
        room_id.Text = Convert.ToString(dear["room_id"]);

        mzh.con.Close();
    }
    protected void save_data_Click(object sender, EventArgs e)
    {
        DBConnection mzh = new DBConnection();
        String SQL;
        string fileName = upload_picture.Text;
    
        ////Upload File to database /////
        SQL = Sql(ref fileName);
        MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
        insertCommandfrommzh.CommandType = CommandType.Text;
        
        insertCommandfrommzh.Parameters.AddWithValue("@2", room_name.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@3", fileName); 
        insertCommandfrommzh.Parameters.AddWithValue("@4", room_no_of_beds.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@6", room_type_id.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@7", room_max_adult.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@8", room_max_child.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@11", room_description.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@12", room_fare.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@13", room_id.Text);

        insertCommandfrommzh.ExecuteNonQuery();
        mzh.con.Close();
        Response.Redirect("~/RoomReport.aspx");
    }

    private string Sql(ref string fileName)
    {
        string SQL;
        if (room_image.HasFile)
        {
            fileName = Path.GetFileName(room_image.PostedFile.FileName);
            room_image.PostedFile.SaveAs(Server.MapPath("uploads/") + fileName);
        }

        if (!String.IsNullOrEmpty(room_id.Text))
        {
            SQL =
                "UPDATE `room` SET `room_name` = @2, `room_image` = @3, `room_no_of_beds` = @4, `room_type_id` = @6, `room_max_adult` = @7, `room_max_child` = @8, `room_description` = @11, `room_fare` = @12 WHERE `room_id` = @13;";
        }
        else
        {
            SQL =
                "INSERT INTO `room` (`room_name`, `room_image`, `room_no_of_beds`, `room_type_id`, `room_max_adult`, `room_max_child`, `room_description`, `room_fare`) VALUES ( @2, @3, @4, @6, @7, @8, @11, @12);";
        }

        return SQL;
    }

    private void FillTypeListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd = new MySqlCommand("Select * From type", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        room_type_id.DataValueField = "type_id";
        room_type_id.DataTextField = "type_name";
        room_type_id.DataSource = data;
        room_type_id.DataBind();
        room_type_id.Items.Insert(0, "Please Select");
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public DataTable showDataListing()
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM `room`,`type` WHERE room_type_id = type_id";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        adp.Fill(data);
        mzh.con.Close();
        return data;
    }
}
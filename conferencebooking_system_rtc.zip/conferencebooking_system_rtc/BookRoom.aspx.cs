﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;


public partial class BookRoom : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String id;
        booking_room_id.Text = Request.QueryString["room_id"];
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=Login to your accout. To access the page !!!");
        }
        if (!Page.IsPostBack)
        {
           
        }

    }
    public DataTable showDataListing()
    {
        DBConnection mzh = new DBConnection();
        String id = Request.QueryString["room_id"];
        String SQL = "SELECT * FROM `room`,`type` WHERE room_type_id = type_id AND room_id = '" + id + "'";
        MySqlCommand cmd = new MySqlCommand(SQL, mzh.con);
        DataTable dt = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
        adp.Fill(dt);
        mzh.con.Close();
        return dt;
    }
    protected void save_data_Click(object sender, EventArgs e)
    {
        String booking_amount = this.getRoomAmount(booking_room_id.Text);
       
        DBConnection mzh = new DBConnection();
        String SQL;
        String userID = Convert.ToString(Session["users_id"]);
        SQL = "INSERT INTO `booking` (`booking_room_id`, `booking_user_id`, `booking_total_adults`, `booking_total_child`, `booking_from_date`, `booking_to_date`, `booking_amount`, `booking_status` ) VALUES (@1, @2, @3, @4, @5, @6, @7, @8);";
        
        MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
        insertCommandfrommzh.CommandType = CommandType.Text;
        
        insertCommandfrommzh.Parameters.AddWithValue("@1", booking_room_id.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@2", userID);
        insertCommandfrommzh.Parameters.AddWithValue("@3", booking_total_adults.Text); 
        insertCommandfrommzh.Parameters.AddWithValue("@4", booking_total_child.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@5", booking_from_date.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@6", booking_to_date.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@7", booking_amount);
        insertCommandfrommzh.Parameters.AddWithValue("@8", "Confirmed");

        insertCommandfrommzh.ExecuteNonQuery();
        long bookingID = insertCommandfrommzh.LastInsertedId;
        mzh.con.Close();
        Response.Redirect("payment.aspx?booking_id="+ bookingID  + "&amt="+ booking_amount);
    }

    public String getRoomAmount(String id)
    {

        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM `room` WHERE room_id = '" + id + "'";
        MySqlCommand command = new MySqlCommand(SQL, mzh.con);
        DataTable data = new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(command);
        adp.Fill(data);
        DataRow dear = data.Rows[0];
        String showAmount = Convert.ToString(dear["room_fare"]);
        mzh.con.Close();
        return showAmount;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using MySql.Data.MySqlClient;


/// <summary>
/// Summary description for DBConnection
/// </summary>
public class DBConnection
{
    public MySqlConnection con;
    public String conString;

    public DBConnection()
    {
        conString = "Server=localhost;Database=room_booking_system;Uid=root;";
        con = new MySqlConnection(conString);
        con.Open();
    }
}
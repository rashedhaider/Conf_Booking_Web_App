﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace conferencebooking_system_rtc
{
    public class TestingGCC
    {
        private Testing _testing;

        public TestingGCC(Testing testing)
        {
            _testing = testing;
        }

        public TestingGCC()
        {
            Name = "Glasgow Conference Centre";
        }

        public object Name { get; set; }


        public object GetName()
        {
            return _testing._name;
        }

        public void SetName(object value)
        {
            _testing._name = value;
        }
    }

    public class Testing
    {
        private string name;
        public object _name;
        private readonly TestingGCC _testingGcc;

        public Testing()
        {
            //
            name = " GlasgowConference Centre ";
            _testingGcc = new TestingGCC(this);
        }

        public TestingGCC TestingGcc
        {
            get { return _testingGcc; }
        }
    }
}
    
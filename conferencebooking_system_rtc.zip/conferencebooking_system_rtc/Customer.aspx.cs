﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;

public partial class Demoasp : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String id;
        if (!Page.IsPostBack && !String.IsNullOrEmpty(Request.QueryString["customer_id"]))
        {
            id = Request.QueryString["customer_id"];
            editData(id);
        }
        if (!Page.IsPostBack)
        {
            FillCityListing();
            FillStateListing();
            FillCountryListing();
        }
    }
    public void editData(String id)
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM customer WHERE customer_id = '" + id + "'";
        MySqlCommand command = new MySqlCommand(SQL, mzh.con);
        DataTable data= new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(command);
        adp.Fill(data);
        DataRow dear = data.Rows[0];
        customer_id.Text = Convert.ToString(dear["customer_id"]);
        customer_name.Text = Convert.ToString(dear["customer_name"]);
        customer_add1.Text = Convert.ToString(dear["customer_add1"]);
        customer_add2.Text = Convert.ToString(dear["customer_add2"]);
        customer_city.Text = Convert.ToString(dear["customer_city"]);
        customer_state.Text = Convert.ToString(dear["customer_state"]);
        customer_country.Text = Convert.ToString(dear["customer_country"]);
        customer_email.Text = Convert.ToString(dear["customer_email"]);
        customer_mobile.Text = Convert.ToString(dear["customer_mobile"]);
        customer_gender.Text = Convert.ToString(dear["customer_gender"]);
        customer_dob.Text = Convert.ToString(dear["customer_dob"]);
        customer_details.Text = Convert.ToString(dear["customer_details"]);

        mzh.con.Close();
    }
    protected void save_data_Click(object sender, EventArgs e)
    {
        var mzh = new DBConnection();
        String SQL;
        string fileName = upload_file.Text;

        ////Upload File to database /////
        if (customer_resume.HasFile)
        {
            fileName = Path.GetFileName(customer_resume.PostedFile.FileName);
            customer_resume.PostedFile.SaveAs(Server.MapPath("uploads/") + fileName);
        }

        if (!String.IsNullOrEmpty(customer_id.Text))
        {
            SQL = "UPDATE `customer` SET  `customer_resume` = @17, `customer_name` = @5, `customer_add1` = @6, `customer_add2` = @7, `customer_city` = @8, `customer_state` = @9, `customer_country` = @10, `customer_email` = @11, `customer_mobile` = @12, `customer_gender` = @13, `customer_dob` = @14, `customer_details` = @15 WHERE `customer_id` = @16";
        }
        else
        {
            SQL = "INSERT INTO `customer` (`customer_username`, `customer_password`, `customer_name`, `customer_add1`, `customer_add2`, `customer_city`, `customer_state`, `customer_country`, `customer_email`, `customer_mobile`, `customer_gender`, `customer_dob`, `customer_details`, `customer_resume`) VALUES (@3, @4, @5, @6, @7, @8, @9, @10, @11, @12, @13, @14, @15, @17)";
        }
        MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
        insertCommandfrommzh.CommandType = CommandType.Text;

        insertCommandfrommzh.Parameters.AddWithValue("@3", customer_username.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@4", customer_password.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@5", customer_name.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@6", customer_add1.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@7", customer_add2.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@8", customer_city.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@9", customer_state.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@10", customer_country.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@11", customer_email.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@12", customer_mobile.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@13", customer_gender.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@14", customer_dob.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@15", customer_details.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@17", fileName);
        insertCommandfrommzh.Parameters.AddWithValue("@16", customer_id.Text);
        insertCommandfrommzh.ExecuteNonQuery();
        mzh.con.Close();
        Response.Redirect("Customer-login.aspx?msg=Your account has been registered successfully !!! Login to your account. "); 
    }
    private void FillCityListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd;
        cmd = new MySqlCommand("Select * From city", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        customer_city.DataValueField = "city_id";
        customer_city.DataTextField = "city_name";
        customer_city.DataSource = data;
        customer_city.DataBind();
        customer_city.Items.Insert(0, "Please Select");
    }
    private void FillStateListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd;
        cmd = new MySqlCommand("Select * From state", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        customer_state.DataValueField = "state_id";
        customer_state.DataTextField = "state_name";
        customer_state.DataSource = data;
        customer_state.DataBind();
        customer_state.Items.Insert(0, "Please Select");
    }
    private void FillCountryListing()
    {
        DBConnection mzh = new DBConnection();
        MySqlCommand cmd;
        cmd = new MySqlCommand("Select * From country", mzh.con);
        cmd.CommandType = CommandType.Text;
        MySqlDataAdapter mzh2 = new MySqlDataAdapter(cmd);
        DataTable data = new DataTable();
        mzh2.Fill(data);
        customer_country.DataValueField = "country_id";
        customer_country.DataTextField = "country_name";
        customer_country.DataSource = data;
        customer_country.DataBind();
        customer_country.Items.Insert(0, "Please Select");
    }
}
﻿using System;   
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class RoomType : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        String id;
        if (Convert.ToString(Session["login"]) != "1")
        {
            Response.Redirect("Login.aspx?msg=Login to your accout. To access the page !!!");
        }
        if (!Page.IsPostBack && !String.IsNullOrEmpty(Request.QueryString["type_id"]))
        {
            id = Request.QueryString["type_id"];
            editData(id);

        }
    }
    public void editData(String id)
    {
        DBConnection mzh = new DBConnection();
        String SQL = "SELECT * FROM type WHERE type_id = '" + id + "'";
        MySqlCommand command = new MySqlCommand(SQL, mzh.con);
        DataTable data= new DataTable();
        MySqlDataAdapter adp = new MySqlDataAdapter(command);
        adp.Fill(data);
        DataRow dear = data.Rows[0];
        type_id.Text = Convert.ToString(dear["type_id"]);
        type_name.Text = Convert.ToString(dear["type_name"]);
        type_description.Text = Convert.ToString(dear["type_description"]);
        mzh.con.Close();
    }
    protected void save_data_Click(object sender, EventArgs e)
    {
        DBConnection mzh = new DBConnection();
        String SQL;

        if (!String.IsNullOrEmpty(type_id.Text))
        {
            SQL = "UPDATE `type` set type_name = @0, type_description = @1 WHERE type_id = @3";
        }
        else
        {
            SQL = "INSERT INTO `type` (type_name, type_description) VALUES(@0,@1)";
        }
        MySqlCommand insertCommandfrommzh = new MySqlCommand(SQL, mzh.con);
        insertCommandfrommzh.CommandType = CommandType.Text;

        insertCommandfrommzh.Parameters.AddWithValue("@0", type_name.Text);
        insertCommandfrommzh.Parameters.AddWithValue("@1", Convert.ToString(type_description.Text));
        insertCommandfrommzh.Parameters.AddWithValue("@3", type_id.Text);
        insertCommandfrommzh.ExecuteNonQuery();
        mzh.con.Close();
        Response.Redirect("~/RoomTypeReport.aspx");
    }
}